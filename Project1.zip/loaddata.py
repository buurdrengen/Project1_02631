# Load data function 
